public abstract class Book {
  public abstract void setTitleString(String aString);
  public abstract String getTitleString();
}
