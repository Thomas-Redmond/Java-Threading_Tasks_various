public class Pet {
	public String classOfAnimal() {
		return("Pet");
	}
}
